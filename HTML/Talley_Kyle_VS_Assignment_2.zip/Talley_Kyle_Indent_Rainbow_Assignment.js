console.log("I got a rainbow!")
console.log("And an extention called JavaScript (ES6) code snippets!")

