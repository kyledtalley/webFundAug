function likeUp(id){
    var element = document.querySelector(`#${id}`)
    console.log(element)
    element.innerText++
}
